class Workout {
  int? id;
  String exercise;
  int duration;
  DateTime date;

  Workout({
    this.id,
    required this.exercise,
    required this.duration,
    required this.date,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'exercise': exercise,
        'duration': duration,
        'date': date.toIso8601String(),
      };
}
