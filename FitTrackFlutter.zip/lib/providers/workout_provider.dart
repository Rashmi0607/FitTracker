import 'package:flutter/material.dart';
import '../models/workout.dart';

class WorkoutProvider extends ChangeNotifier {
  final List<Workout> _workouts = [];

  List<Workout> get workouts => _workouts;

  void addWorkout(Workout workout) {
    _workouts.add(workout);
    notifyListeners();
  }

  int get totalMinutes =>
      _workouts.fold(0, (sum, item) => sum + item.duration);
}
